package fu.de190516.postservice.dto;

import java.math.BigDecimal;

/**
 * Local copy of the UserService UserDTO (data fetched via OpenFeign).
 */
public class UserDTO {

    private Long userId;
    private String username;
    private String email;
    private String role;
    private BigDecimal ratePerPost;
    private Integer maxDailyPosts;
    private Integer level;
    private String status;

    public UserDTO() {
    }

    public UserDTO(Long userId, String username, String email, String role, BigDecimal ratePerPost, Integer maxDailyPosts, Integer level, String status) {
        this.userId = userId;
        this.username = username;
        this.email = email;
        this.role = role;
        this.ratePerPost = ratePerPost;
        this.maxDailyPosts = maxDailyPosts;
        this.level = level;
        this.status = status;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public BigDecimal getRatePerPost() {
        return ratePerPost;
    }

    public void setRatePerPost(BigDecimal ratePerPost) {
        this.ratePerPost = ratePerPost;
    }

    public Integer getMaxDailyPosts() {
        return maxDailyPosts;
    }

    public void setMaxDailyPosts(Integer maxDailyPosts) {
        this.maxDailyPosts = maxDailyPosts;
    }

    public Integer getLevel() {
        return level;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
